

<?php $__env->startSection('tabtitle'); ?>
    City Pop App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    City Population Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <center>
		<h3>Cities in Database</h3>
		
	</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cities.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nickp\Documents\CSCD378HW\cityAPP\cities\resources\views/livewire/index.blade.php ENDPATH**/ ?>