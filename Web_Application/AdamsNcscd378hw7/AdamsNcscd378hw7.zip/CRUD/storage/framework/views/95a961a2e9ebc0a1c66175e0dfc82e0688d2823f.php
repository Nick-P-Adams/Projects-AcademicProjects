<!DOCTYPE html>
<html>
    <head>
        <title>Comics Database</title>
        <link href="https://unpkg.com/spectre.css/dist/spectre.min.css" rel="stylesheet"/>
    </head>
    <body>
        <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\nickp\Documents\CSCD378HW\AdamsNcscd378hw7\CRUD\resources\views/comics/layout.blade.php ENDPATH**/ ?>