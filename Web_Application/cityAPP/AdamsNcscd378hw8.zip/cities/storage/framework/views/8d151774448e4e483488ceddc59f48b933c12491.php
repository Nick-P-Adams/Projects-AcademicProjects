

<?php $__env->startSection('tabtitle'); ?>
    City Pop App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    City Population Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3>Cities in Database</h3>
    <table style="width:700px;" class="table table-striped">
        <tr style="background-color: rgb(0, 73, 6); color:rgb(229,229,229);">
            <th colspan="2" align="center">
                <img width=50 src="<?php echo e(URL::to('/assets/washingtonstate-1638402624944-3230.jpg')); ?>">
                &nbsp; &nbsp;
                Washington State
            </th>
            <th colspan="3" align="center">Populations</th>
        </tr>
        <tr>
            <th>City</th>
            <th>County</th>
            <th align="right">2000</th>
            <th align="right">2010</th>
            <th align="right">2020</th>
        </tr>
        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($city->name); ?></td>
                <td><?php echo e($city->county); ?></td>
                <td align="right"><?php echo e($city->population_2000); ?></td>
                <td align="right"><?php echo e($city->population_2010); ?></td>
                <td align="right"><?php echo e($city->population_2020); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cities.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\clay\CSCD 378\projects\CityNameDbApp\resources\views/cities/index.blade.php ENDPATH**/ ?>