

<?php $__env->startSection('tabtitle'); ?>
    City Pop App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    City Population Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <center>
		<h3>Cities in Database</h3>
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post', [])->html();
} elseif ($_instance->childHasBeenRendered('cUKaidu')) {
    $componentId = $_instance->getRenderedChildComponentId('cUKaidu');
    $componentTag = $_instance->getRenderedChildComponentTagName('cUKaidu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cUKaidu');
} else {
    $response = \Livewire\Livewire::mount('post', []);
    $html = $response->html();
    $_instance->logRenderedChild('cUKaidu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cities.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nickp\Documents\CSCD378HW\cityAPP\cities\resources\views/cities/index.blade.php ENDPATH**/ ?>