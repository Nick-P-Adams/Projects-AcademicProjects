<?php $__env->startSection('content'); ?>
        <center>
            <span style="font-family:Impact"><div class="hero hero-sm bg-primary">
                <h1>Comics Index</h1>
            </div>
                <div style="font-family:helvetica">
                    <a class="btn btn-primary btn-lg btn-success" href="<?php echo e(route('comics.create')); ?>">New Comic</a>
                </div><br>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <span><?php echo e($message); ?></span>
                    </div>
                <?php endif; ?>
            </span>

            <span style="font-family:helvetica">
            <table class="table table-striped table-hover">
                <thead>
                    <tr ALIGN="CENTER">
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('title', 'Title'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('volume', 'Volume'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('volume_id', 'Volume ID'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('issue_num', 'Issue Number'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('pub_date', 'Publish Date'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('condition', 'Condition'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('writer_name', 'Writer'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('artist_name', 'Artist'));?></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr ALIGN="CENTER">
                        <td><?php echo e($comic->title); ?></td>
                        <td><?php echo e($comic->volume); ?></td>
                        <td><?php echo e($comic->volume_id); ?></td>
                        <td><?php echo e($comic->issue_num); ?></td>
                        <td><?php echo e($comic->pub_date); ?></td>
                        <td><?php echo e($comic->condition); ?></td>
                        <td><?php echo e($comic->writer_name); ?></td>
                        <td><?php echo e($comic->artist_name); ?></td>
                        <td><div class="btn-group btn-group-block"><form action="<?php echo e(route('comics.destroy',$comic->id)); ?>" method="POST">
                            <a class="btn btn-primary" href="<?php echo e(route('comics.show',$comic->id)); ?>">Show</a>
                            <a class="btn btn-primary" href="<?php echo e(route('comics.edit',$comic->id)); ?>">Edit</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Do you really want to delete the comic?')" class="btn btn-error">Delete</button>
                            </form></div>
                        </td>
                    </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div  style="width:25%;">
                <?php echo $comics->appends(Request::except('page'))->render('vendor.pagination.default'); ?>

            </div>
            </span>
        </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('comics.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nickp\Documents\CSCD378HW\AdamsNcscd378hw7\CRUD\resources\views/comics/index.blade.php ENDPATH**/ ?>