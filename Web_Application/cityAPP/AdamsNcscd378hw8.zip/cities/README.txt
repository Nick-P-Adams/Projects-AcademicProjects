To run the application:

0. Open a command prompt and navigate to the directory of the application (the directory containing this README.txt).

1. Restore the application's vendor directory
    a. Run the command 'composer install'
    
2. Start the Laravel Server
    a. Run the command 'php artisan serve'

3. Open a browser and go to the URL 'http://127.0.0.1:8000/cities'