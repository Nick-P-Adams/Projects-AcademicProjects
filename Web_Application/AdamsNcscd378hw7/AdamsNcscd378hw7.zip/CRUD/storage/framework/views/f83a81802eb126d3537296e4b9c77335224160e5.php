<?php $__env->startSection('content'); ?>
<div class="card hero hero-sm bg-primary" align="center">
    <span style="font-family:impact">
    <div class="card-header">
        <div class="card-title h5"><?php echo e($comic->title); ?></div>
        <div class="card-subtitle text-gray"><?php echo e($comic->volume); ?></div>
    </div>
    </span>

    <div class="card-image">
        <img src="<?php echo e($comic->image_URL); ?>" class="img-responsive" width="600" height="800">
    </div>
    <span style="font-family:helvetica">
    <div class="card-body">
        <div class="form-group">
            <Strong>Comic Title</Strong>
            <br><?php echo e($comic->title); ?>

        </div>
        <div class="form-group">
            <Strong>Volume</Strong>
            <br><?php echo e($comic->volume); ?>

        </div>
        <div class="form-group">
            <Strong>Volume ID</Strong>
            <br><?php echo e($comic->volume_id); ?>

        </div>
        <div class="form-group">
            <Strong>Issue Number</Strong>
            <br><?php echo e($comic->issue_num); ?>

        </div>
        <div class="form-group">
            <Strong>Published</Strong>
            <br><?php echo e($comic->pub_date); ?>

        </div>
        <div class="form-group">
            <Strong>Condition</Strong>
            <br><?php echo e($comic->condition); ?>

        </div>
        <div class="form-group">
            <Strong>Writers Name</Strong>
            <br><?php echo e($comic->writer_name); ?>

        </div>
        <div class="form-group">
            <Strong>Artists Name</Strong>
            <br><?php echo e($comic->artist_name); ?>

        </div>
        <div class="form-group" style="width:50%;">
            <Strong>Description</Strong>
            <br><?php echo e($comic->description); ?>

        </div>
    </div>

    <div class="card-footer">
        <div>
            <form action="<?php echo e(route('comics.destroy',$comic->id)); ?>" method="POST">
                <a class="btn" href="<?php echo e(route('comics.index')); ?>">Back</a>
                <a class="btn" href="<?php echo e(route('comics.edit',$comic->id)); ?>">Edit</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" onclick="return confirm('Do you really want to delete the comic?')" class="btn btn-error">Delete</button>
            </form>
        </div>
    </div>
    </span>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('comics.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nickp\Documents\CSCD378HW\AdamsNcscd378hw7\CRUD\resources\views/comics/show.blade.php ENDPATH**/ ?>