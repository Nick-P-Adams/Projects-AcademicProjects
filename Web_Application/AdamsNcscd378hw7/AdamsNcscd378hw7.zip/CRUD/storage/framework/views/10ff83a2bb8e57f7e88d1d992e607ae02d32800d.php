<!--- <!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Comics Index</title>

        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    </head>
    <body>
        <center>
            <h1>Comics</h1>
            <table BORDER="4" WIDTH="100%" CELLPADDING="4" CELLSPACING="3">
                <tr ALIGN="CENTER">
                    <td>Title</td>
                    <td>Volume</td>
                    <td>Volume ID</td>
                    <td>Issue Number</td>
                    <td>Publish Date</td>
                    <td>Condition</td>
                    <td>Writer</td>
                    <td>Artist</td>
                </tr>

                <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr ALIGN="CENTER">
                    <td><?php echo e($comic->title); ?></td>
                    <td><?php echo e($comic->volume); ?></td>
                    <td><?php echo e($comic->volume_id); ?></td>
                    <td><?php echo e($comic->issue_num); ?></td>
                    <td><?php echo e($comic->pub_date); ?></td>
                    <td><?php echo e($comic->condition); ?></td>
                    <td><?php echo e($comic->writer_name); ?></td>
                    <td><?php echo e($comic->artist_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </center>
    </body>
    <?php echo e($comics->links('vendor.pagination.default')); ?>

</html> -->


<?php $__env->startSection('content'); ?>
        <center>
            <h1>Comics</h1>
            <table BORDER="4" WIDTH="100%" CELLPADDING="4" CELLSPACING="3">
                <tr ALIGN="CENTER">
                    <td>Title</td>
                    <td>Volume</td>
                    <td>Volume ID</td>
                    <td>Issue Number</td>
                    <td>Publish Date</td>
                    <td>Condition</td>
                    <td>Writer</td>
                    <td>Artist</td>
                </tr>

                <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr ALIGN="CENTER">
                    <td><?php echo e($comic->title); ?></td>
                    <td><?php echo e($comic->volume); ?></td>
                    <td><?php echo e($comic->volume_id); ?></td>
                    <td><?php echo e($comic->issue_num); ?></td>
                    <td><?php echo e($comic->pub_date); ?></td>
                    <td><?php echo e($comic->condition); ?></td>
                    <td><?php echo e($comic->writer_name); ?></td>
                    <td><?php echo e($comic->artist_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </center>
    <?php echo e($comics->links('vendor.pagination.default')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nickp\Documents\CSCD378HW\AdamsNcscd378hw7\CRUD\resources\views/index.blade.php ENDPATH**/ ?>