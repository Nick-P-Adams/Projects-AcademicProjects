Nick Adams
CSCD 378 HW 7

Instructions: 
First things first, open your terminal and navigate by changing your directory to the folder that was just extracted containing this file. 
Example: (cd c:/Users/user/Downloads/AdamsNcscd378hw7/CRUD) Next we need to rebuild the vendor file so from the command prompt type "composer install"
once that is finished the next step will be to type "php artisan serve" into the command prompt which will start the local web server. 
Now you can open a web brower I used microsoft edge and in the url type "http://127.0.0.1:8000/comics" this will display the paginated comics table 
you can view, edit, or delete any of the entries. You may also click on the clickable column headers to sort by that column. As well as, click the new comic button
located at the top of the page to make an entirley new entry. Whenever you are done viewing in the command prompt type "Ctrl+c" to end the web server session. 

If URL http://127.0.0.1:8000/comics does not work use http://127.0.0.1:8000/index