<?php return array (
  'post' => 'App\\Http\\Livewire\\Post',
);