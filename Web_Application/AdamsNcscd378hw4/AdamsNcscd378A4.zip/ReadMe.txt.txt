Nick Adams
CSCD HW 4 

Instructions: First you will open the command prompt and change your directory to the folder containing both index.html and MortgageCalculator.php.
Insure there are no other index.html or index.php files in the same folder. (Example cd c:/Users/user/Downloads/AdamsNcscd378A4) Next in order to start the server
just enter "php -S 127.0.0.1:8000" as instructed in the specifications (if for whatever reason your local host ip is different use that ip instead). The server will start 
after you hit enter and all that is left is to open your browser of choice I used Edge. In the URL bar enter 127.0.0.1:8000 this will make the request for the index.html file
from the web server. Just enter values into the form and hit submit to get the output. 