<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
<link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('tabtitle'); ?></title>
	<?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div class="container">
        <center><h1><?php echo $__env->yieldContent('title'); ?></h1></center>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post')->html();
} elseif ($_instance->childHasBeenRendered('h2C6b09')) {
    $componentId = $_instance->getRenderedChildComponentId('h2C6b09');
    $componentTag = $_instance->getRenderedChildComponentTagName('h2C6b09');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h2C6b09');
} else {
    $response = \Livewire\Livewire::mount('post');
    $html = $response->html();
    $_instance->logRenderedChild('h2C6b09', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
	
	<?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\Users\nickp\Documents\CSCD378HW\cityAPP\cities\resources\views/layouts/app.blade.php ENDPATH**/ ?>