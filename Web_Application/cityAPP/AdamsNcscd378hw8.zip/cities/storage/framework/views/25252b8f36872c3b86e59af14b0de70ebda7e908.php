

<?php $__env->startSection('content'); ?>
<h3>Cities in Database</h1>
    <table class="table">
        <tr>
            <th>Name</th>
            <th>State</th>
            <th>Population 2000</th>
            <th>Population 2010</th>
            <th>Population 2020</th>
        </tr>
        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($city->name); ?></td>
            <td><?php echo e($city->state); ?></td>
            <td><?php echo e($city->population_2000); ?></td>
            <td><?php echo e($city->population_2010); ?></td>
            <td><?php echo e($city->population_2020); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joseph McConnell\Desktop\New folder (4)\CityNameDbApp\resources\views/cities/index.blade.php ENDPATH**/ ?>