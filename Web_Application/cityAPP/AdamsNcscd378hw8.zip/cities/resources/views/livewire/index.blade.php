@extends('cities.layout')

@section('tabtitle')
    City Pop App
@endsection

@section('title')
    City Population Data
@endsection

@section('content')
    <center>
		<h3>Cities in Database</h3>
		<livewire:post>
	</center>
@endsection
