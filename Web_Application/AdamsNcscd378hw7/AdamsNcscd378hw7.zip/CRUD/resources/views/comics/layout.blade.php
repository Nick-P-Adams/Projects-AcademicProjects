<!DOCTYPE html>
<html>
    <head>
        <title>Comics Database</title>
        <link href="https://unpkg.com/spectre.css/dist/spectre.min.css" rel="stylesheet"/>
    </head>
    <body>
        <div class="container">
        @yield('content')
        </div>
    </body>
</html>
